import numpy
import pylab
pylab.ion()

# http://wiki.scipy.org/Cookbook/Matplotlib/LaTeX_Examples
pts_per_inch=72.27       # this is a latex constant, don't change it.
text_width_in_pts=246.0  # write "\the\textwidth" (or "\the\columnwidth" for a 2 collumn text)
                         # inside a figure environment in latex, the result will be on the dvi/pdf next to the figure. See url above.
text_width_in_inches=text_width_in_pts/pts_per_inch
golden_ratio=0.618       # make rectangles with a nice proportion
inverse_latex_scale=2    # figure.png or figure.eps will be intentionally larger, because it is prettier
                         # when compiling latex code, use \includegraphics[scale=(1/inverse_latex_scale)]{figure}
fig_proportion = (1.0) # we want the figure to occupy 2/3 (for example) of the text width
csize=inverse_latex_scale*fig_proportion*text_width_in_inches
fig_size=(1.0*csize,golden_ratio*csize)  # always 1.0 on the first argument
fig=pylab.figure(1,figsize=fig_size)     # figsize accepts only inches. if you rather think in cm, change the code yourself.
fig.clf()
fig.subplots_adjust(top=0.95,bottom=0.02,left=0.02,right=0.95,hspace=0.00,wspace=0.03)
ax=fig.add_subplot(111)

text_size=inverse_latex_scale*12  # find out the fontsize of your latex text, and put it here
tick_size=inverse_latex_scale*8
# learn how to configure: http://matplotlib.sourceforge.net/users/customizing.html
params = {'backend': 'ps',
          'axes.labelsize': text_size,
          #'axes.linewidth' : 0,
          'text.fontsize': text_size,
          'legend.fontsize': tick_size,
          'legend.handlelength': 2.5,
          'legend.borderaxespad': 0,
          'xtick.labelsize': tick_size,
          'ytick.labelsize': tick_size,
          'font.family':'serif',
          'font.size': text_size,
          'font.serif':['Computer Modern Roman'], # Times, Palatino, New Century Schoolbook, Bookman, Computer Modern Roman
          'ps.usedistiller': 'xpdf',
          'text.usetex': True,
          'text.latex.preamble' : [ '\usepackage{chemarrow}', # include here any neede package for latex
                                    '\usepackage{amsmath}' ] ,
          'figure.figsize': fig_size}
pylab.rcParams.update(params)

pylab.hold('on')


def texturize(region, axes, texture,ecolor):
    from matplotlib.patches import PathPatch
    #p.set_facecolors("none")
    for path in region.get_paths():
        p1 = PathPatch(path, fc="none",ec=ecolor, hatch=texture)
        axes.add_patch(p1)
        p1.set_zorder(p.get_zorder()-0.0)

u = numpy.arange(-2,2,0.01)
delta = numpy.arange(-0,16,0.01)
a0 = 0
a1 = 0.5

eps_T = delta / (2 - a1 + 2*numpy.sqrt(1-a1))
eps_H = delta*0 + 1.0/a1

#ax=pylab.subplot(111)
ax.spines['left'].set_position('zero')
ax.spines['right'].set_color('none')
ax.spines['bottom'].set_position('zero')
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.yaxis.set_ticks_position('left')

c = "red"
pylab.plot(delta,eps_T,color=c)
p = pylab.fill_between(delta, eps_T,y2=0, facecolor='red', alpha=0.0)
texturize(p, ax, "\\",c)
c = "green"
pylab.plot(delta,eps_H,color=c)
q = pylab.fill_between(delta, eps_H,y2=0, facecolor='green', alpha=0.2)
texturize(q, ax, None,c)

pylab.axis([-1.4,15,-0.5,3])
pylab.text(14.5,-0.25,r'$\delta$',fontsize=22)
pylab.text(0.3,2.8,r'$\epsilon$',fontsize=22)
pylab.xticks([(2-a1+2*numpy.sqrt(1-a1))/a1],[r'$\delta_{c2p}$'])
pylab.yticks([1/a1],[r'$1/a_1$'])
pylab.legend([r'$\epsilon_T=\frac{\delta}{2-a_1+2\sqrt{1+a_1}}$',r'$\epsilon_H=1/a_1$'])
ax.yaxis.tickspad = -100

pylab.show()
pylab.savefig('parameter_space.png')
