This thesis template was prepared by Yair Mau in October 2013, based on his phd thesis.
This template is in accord with the requirements of Kreitman School, of the Ben-Gurion University of the Negev.

1 - The whole thesis can be prepared by compiling "main.tex".
2 - You can compile each chapter separately, which is very handy. Try it!
3 - The figures are .png, so it is assumed you are using "pdflatex". You can also use .eps if you like.
4 - Useful tip: compiling the whole thesis can take several seconds, so if you want to speed the process up, include "draft" in the \documentclass arguments:
    \documentclass[a4paper,12pt, draft]{extreport}
    This will produce a thesis with blank squares where the figures should be.
5 - Don't forget to put your name in the front pages, otherwise Harry Potter will receive a phd. Again.
6 - When you put an Abstract in the middle of a document, it will reset the page numbering to 1, and the reset again after it is finished.
    I prepared a nice hack to circumvent this problem, so it should be all right.
7 - If you are required to prepare front pages in hebrew, take a look at the file "abstract_heb.rtf".
    (some editing might be needed, linux doesn't like these kind of files...)
8 - If you have improvements to this template, feel free to spread them around yourself, make other student's life easier :)
    
Yair Mau, 23 October 2013
