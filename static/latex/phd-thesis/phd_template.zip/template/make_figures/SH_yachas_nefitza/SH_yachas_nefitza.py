import numpy
import pylab
pylab.ion()

# http://wiki.scipy.org/Cookbook/Matplotlib/LaTeX_Examples
pts_per_inch=72.27       # this is a latex constant, don't change it.
text_width_in_pts=390.0  # write "\the\textwidth" (or "\showthe\columnwidth" for a 2 collumn text)
                         # inside a figure environment in latex, the result will be on the dvi/pdf next to the figure. See url above.
text_width_in_inches=text_width_in_pts/pts_per_inch
golden_ratio=0.618       # make rectangles with a nice proportion
inverse_latex_scale=2    # figure.png or figure.eps will be intentionally larger, because it is prettier
                         # when compiling latex code, use \includegraphics[scale=(1/inverse_latex_scale)]{figure}
fig_proportion = (2.0/3.0) # we want the figure to occupy 2/3 (for example) of the text width
csize=inverse_latex_scale*fig_proportion*text_width_in_inches
fig_size=(1.0*csize,golden_ratio*csize)  # always 1.0 on the first argument
fig=pylab.figure(1,figsize=fig_size)     # figsize accepts only inches. if you rather think in cm, change the code yourself.
fig.clf()
fig.subplots_adjust(top=0.98,bottom=0.15,left=0.08,right=0.98,hspace=0.00,wspace=0.03)
ax=fig.add_subplot(111)

text_size=inverse_latex_scale*12  # find out the fontsize of your latex text, and put it here
tick_size=inverse_latex_scale*8
# learn how to configure: http://matplotlib.sourceforge.net/users/customizing.html
params = {'backend': 'ps',
          'axes.labelsize': text_size,
          #'axes.linewidth' : 0,
          'text.fontsize': text_size,
          'legend.fontsize': text_size,
          'legend.handlelength': 2.5,
          'legend.borderaxespad': 0,
          'xtick.labelsize': tick_size,
          'ytick.labelsize': tick_size,
          'font.family':'serif',
          'font.size': text_size,
          'font.serif':['Computer Modern Roman'], # Times, Palatino, New Century Schoolbook, Bookman, Computer Modern Roman
          'ps.usedistiller': 'xpdf',
          'text.usetex': True,
          'text.latex.preamble' : [ '\usepackage{chemarrow}', # include here any neede package for latex
                                    '\usepackage{amsmath}' ] ,
          'figure.figsize': fig_size}
pylab.rcParams.update(params)

pylab.hold('on')


eps1 = -0.5
eps2 =  0.0
eps3 =  0.5

k0   =  1.0
k = numpy.linspace(-2,2,1001)
sigma  = lambda eps: eps - (k**2-k0**2)**2

pylab.axhline(y=0,ls='--',color='black')

pylab.plot(k,sigma(eps1),'r')
pylab.plot(k,sigma(eps2),'b')
pylab.plot(k,sigma(eps3),'g')

pylab.text(0.9,-0.45,r"$\epsilon<0$",fontsize=20)
pylab.text(0.95,0.05,r"$\epsilon=0$",fontsize=20)
pylab.text(1.0,0.55,r"$\epsilon>0$",fontsize=20)

pylab.xlabel(r"$k$")
pylab.ylabel(r"$\sigma$",rotation='horizontal')

pylab.xticks([-k0,0,k0],[r"$-k_0$",r"$0$",r"$k_0$"])
pylab.yticks([0],[r"$0$"])

pylab.axis([0,1.5,-1.8,1.1])

pylab.show()

pylab.savefig("SH_nefitza.png")
pylab.savefig("SH_nefitza.eps")
